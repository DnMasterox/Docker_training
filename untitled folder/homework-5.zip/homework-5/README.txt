Build image locally:
docker build -t extsoft/allure-docker-example .

Docker run:
1. docker run -t -i -p 8000:80 extsoft/allure-docker-example
2. Open Allure report on your host machine: http://localhost:8000/#/

